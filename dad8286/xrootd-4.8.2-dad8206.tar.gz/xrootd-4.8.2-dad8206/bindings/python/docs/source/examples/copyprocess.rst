========================
``CopyProcess`` examples
========================

.. include:: ../../../examples/copyprocess.py
   :start-line: 1
   :end-line: 3

.. literalinclude:: ../../../examples/copyprocess.py
   :lines: 29-

.. include:: ../../../examples/copyprocess.py
   :start-line: 4
   :end-line: 27
