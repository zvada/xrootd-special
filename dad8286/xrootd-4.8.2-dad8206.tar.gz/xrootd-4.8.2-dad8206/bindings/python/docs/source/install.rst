===========================
**Installing** ``pyxrootd``
===========================

.. include:: ../../README.rst
   :start-line: 8